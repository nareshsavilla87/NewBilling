angular.module('configurations', [])
.constant('TENANT','default')
.constant('API_VERSION',selfcareModels.OBS_URL)
.constant('CONTENT_TYPE','application/json; charset=utf-8');