	korta 	= {
		
		termsAndConditions_en_locale : "I will be showing how to create a Page and add content toit .ok sir Today I want all off you to start puting the feature" 
				 +"functionality that has been developed No matter on spelling / Sentence / Grammer .. Just add the data .. Will review as well we can get"
				 +"it reviewed by our Pavan if necessary .. If the information is available it will be easy for every on to know as Knowledge base .. and address"
				 +"the Enhancements Quickly .. Well now I will add One Page.1. How to add a Page 2. Basic Format to use while adding the content to that Page"
				 +"The Structure is like this .. First Main Page as landing Page .. http:wiki.openbillingsystem.com/mw19/ Here you can see 6 Sections .. But we are going to use"
				 +"the First one -- Open Billing System Every click in wiki is basically a Page ..With in the Page we have the relavent content ..",
				 
		termsAndConditions_is_locale : "﻿Þjónustuveita Thor Telecom á Internetinu."
				+"Starfsemi þjónustuveitu Thor Telecom felst í aðgangssölu að afþreyingar- og upplýsingaefni."
				+"Efni þetta er m.a. sjónvarpsrásir, kvikmyndir. VOD þjónusta, hugbúnaður margskonar og netþjónusta."
				+"Hluti þjónustunnar er gjaldfrír en fyrir annað gjaldskylt efni er greitt samkvæmt gjaldskrá Thor Telecom."
				+"Eftirfarandi skilmálar eiga við um aðgang og afhendingu frá þjónustuveitu Thor Telecom.kt 591007-1140 og er bæði viðskipavinum að þjónustunni og öðrum notendum hennar skylt að hlíta þeim."
				+"																	    	"
				+"Þjónustu skilmálar Thor Telecom"
				+"Viðskiptavinir Thor Telecom njóta þjónustu fyrirtækisins með netmiðlum ýmiskonar."
				+"Þjónustan er skilyrt að kaupendum með íslenska kennitölu og lögheimili."
				+"Viðskiptavinur skráður fyrir þjónustunni ber ábyrgð á allri notkun henni tengdri."
				+"Kaupendum þjónustu er óheimilt að áframdreifa efni frá gagnaveitu ThorTelecom utan heimilis."
				+"Greiðslufyrirkomulag er netgreiðsla í gegn um kortafyrirtæki og þjónusta afhendist kaupanda við staðfestingu á greiðslu."
				+"Við kaup á þjónustu ThorTelecom telst vera komin staðfesting viðskiptavinar á skilmálum þessum."
				+"																			"			
				+"Thor Telecom áskilur sér rétt til breytinga á skilmálum þessum og eru allar slíkar kynntar á vefsíðu fyrirtækisins, www.thortelecom.is"
				+"Thor Telecom getur ekki ábyrgst eftirfarandi."
				+"Bilanir, takamörkuðum gagnahraða eða rekstrartruflanir á nettengingu viðskiptavinar."
				+"Bilanir eða rekstrartruflanir á öðrum búnaði viðskiptavinar tengdum þjónustuveitu Thor Telecom."
				+"Bilanir eða rekstrartruflanir á greiðslukerfi kortafyrirtækja."
				+"Ef staðsetning viðskiptavinar veldur takmörkun á þjónustu vegna höfundaréttar."
				+"Tjón eða slys viðskiptavinar eða þriðja aðila sem hlotist getur af uppsetningu eða notkun."
				+"																				"
				+"Brot á skilmálum þessum geta valdið tafalausri lokun á þjónustu."
				+"																				"
				+"Viðskiptavinur getur krafist endurgreiðslu ef upp koma þjónustu vandamál sem rekja má til bilanna búnaðar Thor Telecom."
				+"Bótaskylda getur þó aldrei numið hærri upphæð en sem nemur andvirði þeirrar þjónustu sem keypt var."
				+"Bótaskylda er einungis gagnvart notanda greiddar þjónustu, ekki gangvart þriðja aðila."
				+"Minniháttar rekstrartruflanir Thor Telecom skapa ekki bótaskildu eða endurkröfurétt."
				+"Minniháttar rekstrartruflanir eru skilgreindar sem óvirk þjónusta í 2 klst eða skemur."
				+"																				"
				+"Verð"
				+"Vinsamlegast athugið að verð á netinu getur breyst án fyrirvara."
				+"																				"
				+"Skattar og gjöld"
				+"Öll verð í netversluninni eru með VSK."
				+"																				"
				+"Trúnaður"
				+"Seljandi heitir kaupanda fullum trúnaði um allar þær upplýsingar sem kaupandi gefur upp í tengslum við viðskiptin. Upplýsingar verða ekki afhentar þriðja aðila undir neinum kringumstæðum."
				+"																				"
				+"Um fjarskiptaþjónustu gilda lög um fjarskipti nr. 81/2003 ásamt síðari breytingum. Brot á lögum og reglum Póst og fjarskiptastonunar getur valdið tafalausri lokun á þjónustu.",
				
	};
	dalpay 	= {
		
		termsAndConditions_en_locale : "I will be showing how to create a Page and add content toit .ok sir Today I want all off you to start puting the feature" 
			+"functionality that has been developed No matter on spelling / Sentence / Grammer .. Just add the data .. Will review as well we can get"
			+"it reviewed by our Pavan if necessary .. If the information is available it will be easy for every on to know as Knowledge base .. and address"
			+"the Enhancements Quickly .. Well now I will add One Page.1. How to add a Page 2. Basic Format to use while adding the content to that Page"
			+"The Structure is like this .. First Main Page as landing Page .. http:wiki.openbillingsystem.com/mw19/ Here you can see 6 Sections .. But we are going to use"
			+"the First one -- Open Billing System Every click in wiki is basically a Page ..With in the Page we have the relavent content ..",
			
		termsAndConditions_is_locale : "Ég mun vera að sýna hvernig á að búa til síðu og bæta við efni Toit .ok herra dag ÉG vilja allir burt þér að byrja puting aðgerðina" 
			+"virkni sem hefur verið þróað Sama á stafsetningu / setning / málfræði .. Bara bæta gögn .. Mun endurskoða eins vel og við getum fengið"
			+"það skoðað af Pavan okkar ef þörf krefur .. Ef upplýsingar liggja það verður auðvelt fyrir alla á að vita sem þekkingargrunn .. og heimilisfang"
			+"að Aukahlutir Fljótt .. Jæja nú er ég mun bæta One Page.1. Hvernig á að bæta við 2. Basic snið til nota en bæta efni á þá síðu"
			+"The Structure er svona .. First Main Page áfangasíðu .. http: wiki.openbillingsystem.com/mw19/ Hér getur þú séð 6 kafla .. En við erum að fara að nota"
			+"Sú fyrsta - Open Billing System Hvern smell í wiki er í grundvallaratriðum a Page ..With í Page við höfum Relavent efni .. ",
	};
	globalpay 	= {
		
		termsAndConditions_en_locale : "I will be showing how to create a Page and add content toit .ok sir Today I want all off you to start puting the feature" 
			+"functionality that has been developed No matter on spelling / Sentence / Grammer .. Just add the data .. Will review as well we can get"
			+"it reviewed by our Pavan if necessary .. If the information is available it will be easy for every on to know as Knowledge base .. and address"
			+"the Enhancements Quickly .. Well now I will add One Page.1. How to add a Page 2. Basic Format to use while adding the content to that Page"
			+"The Structure is like this .. First Main Page as landing Page .. http:wiki.openbillingsystem.com/mw19/ Here you can see 6 Sections .. But we are going to use"
			+"the First one -- Open Billing System Every click in wiki is basically a Page ..With in the Page we have the relavent content ..",
			
		termsAndConditions_is_locale : "Ég mun vera að sýna hvernig á að búa til síðu og bæta við efni Toit .ok herra dag ÉG vilja allir burt þér að byrja puting aðgerðina" 
			+"virkni sem hefur verið þróað Sama á stafsetningu / setning / málfræði .. Bara bæta gögn .. Mun endurskoða eins vel og við getum fengið"
			+"það skoðað af Pavan okkar ef þörf krefur .. Ef upplýsingar liggja það verður auðvelt fyrir alla á að vita sem þekkingargrunn .. og heimilisfang"
			+"að Aukahlutir Fljótt .. Jæja nú er ég mun bæta One Page.1. Hvernig á að bæta við 2. Basic snið til nota en bæta efni á þá síðu"
			+"The Structure er svona .. First Main Page áfangasíðu .. http: wiki.openbillingsystem.com/mw19/ Hér getur þú séð 6 kafla .. En við erum að fara að nota"
			+"Sú fyrsta - Open Billing System Hvern smell í wiki er í grundvallaratriðum a Page ..With í Page við höfum Relavent efni .. ",
	};
	paypal 	= {
		
		termsAndConditions_en_locale : "I will be showing how to create a Page and add content toit .ok sir Today I want all off you to start puting the feature" 
			+"functionality that has been developed No matter on spelling / Sentence / Grammer .. Just add the data .. Will review as well we can get"
			+"it reviewed by our Pavan if necessary .. If the information is available it will be easy for every on to know as Knowledge base .. and address"
			+"the Enhancements Quickly .. Well now I will add One Page.1. How to add a Page 2. Basic Format to use while adding the content to that Page"
			+"The Structure is like this .. First Main Page as landing Page .. http:wiki.openbillingsystem.com/mw19/ Here you can see 6 Sections .. But we are going to use"
			+"the First one -- Open Billing System Every click in wiki is basically a Page ..With in the Page we have the relavent content ..",
		
		termsAndConditions_is_locale : "Ég mun vera að sýna hvernig á að búa til síðu og bæta við efni Toit .ok herra dag ÉG vilja allir burt þér að byrja puting aðgerðina" 
			+"virkni sem hefur verið þróað Sama á stafsetningu / setning / málfræði .. Bara bæta gögn .. Mun endurskoða eins vel og við getum fengið"
			+"það skoðað af Pavan okkar ef þörf krefur .. Ef upplýsingar liggja það verður auðvelt fyrir alla á að vita sem þekkingargrunn .. og heimilisfang"
			+"að Aukahlutir Fljótt .. Jæja nú er ég mun bæta One Page.1. Hvernig á að bæta við 2. Basic snið til nota en bæta efni á þá síðu"
			+"The Structure er svona .. First Main Page áfangasíðu .. http: wiki.openbillingsystem.com/mw19/ Hér getur þú séð 6 kafla .. En við erum að fara að nota"
			+"Sú fyrsta - Open Billing System Hvern smell í wiki er í grundvallaratriðum a Page ..With í Page við höfum Relavent efni .. ",
	};
	neteller 	= {
		
		termsAndConditions_en_locale : "I will be showing how to create a Page and add content toit .ok sir Today I want all off you to start puting the feature" 
			+"functionality that has been developed No matter on spelling / Sentence / Grammer .. Just add the data .. Will review as well we can get"
			+"it reviewed by our Pavan if necessary .. If the information is available it will be easy for every on to know as Knowledge base .. and address"
			+"the Enhancements Quickly .. Well now I will add One Page.1. How to add a Page 2. Basic Format to use while adding the content to that Page"
			+"The Structure is like this .. First Main Page as landing Page .. http:wiki.openbillingsystem.com/mw19/ Here you can see 6 Sections .. But we are going to use"
			+"the First one -- Open Billing System Every click in wiki is basically a Page ..With in the Page we have the relavent content ..",
			
		termsAndConditions_is_locale : "Ég mun vera að sýna hvernig á að búa til síðu og bæta við efni Toit .ok herra dag ÉG vilja allir burt þér að byrja puting aðgerðina" 
			+"virkni sem hefur verið þróað Sama á stafsetningu / setning / málfræði .. Bara bæta gögn .. Mun endurskoða eins vel og við getum fengið"
			+"það skoðað af Pavan okkar ef þörf krefur .. Ef upplýsingar liggja það verður auðvelt fyrir alla á að vita sem þekkingargrunn .. og heimilisfang"
			+"að Aukahlutir Fljótt .. Jæja nú er ég mun bæta One Page.1. Hvernig á að bæta við 2. Basic snið til nota en bæta efni á þá síðu"
			+"The Structure er svona .. First Main Page áfangasíðu .. http: wiki.openbillingsystem.com/mw19/ Hér getur þú séð 6 kafla .. En við erum að fara að nota"
			+"Sú fyrsta - Open Billing System Hvern smell í wiki er í grundvallaratriðum a Page ..With í Page við höfum Relavent efni .. ",
	};
	internalPayment 	= {
		
		termsAndConditions_en_locale : "I will be showing how to create a Page and add content toit .ok sir Today I want all off you to start puting the feature" 
			+"functionality that has been developed No matter on spelling / Sentence / Grammer .. Just add the data .. Will review as well we can get"
			+"it reviewed by our Pavan if necessary .. If the information is available it will be easy for every on to know as Knowledge base .. and address"
			+"the Enhancements Quickly .. Well now I will add One Page.1. How to add a Page 2. Basic Format to use while adding the content to that Page"
			+"The Structure is like this .. First Main Page as landing Page .. http:wiki.openbillingsystem.com/mw19/ Here you can see 6 Sections .. But we are going to use"
			+"the First one -- Open Billing System Every click in wiki is basically a Page ..With in the Page we have the relavent content ..",
			
		termsAndConditions_is_locale : "Ég mun vera að sýna hvernig á að búa til síðu og bæta við efni Toit .ok herra dag ÉG vilja allir burt þér að byrja puting aðgerðina" 
			+"virkni sem hefur verið þróað Sama á stafsetningu / setning / málfræði .. Bara bæta gögn .. Mun endurskoða eins vel og við getum fengið"
			+"það skoðað af Pavan okkar ef þörf krefur .. Ef upplýsingar liggja það verður auðvelt fyrir alla á að vita sem þekkingargrunn .. og heimilisfang"
			+"að Aukahlutir Fljótt .. Jæja nú er ég mun bæta One Page.1. Hvernig á að bæta við 2. Basic snið til nota en bæta efni á þá síðu"
			+"The Structure er svona .. First Main Page áfangasíðu .. http: wiki.openbillingsystem.com/mw19/ Hér getur þú séð 6 kafla .. En við erum að fara að nota"
			+"Sú fyrsta - Open Billing System Hvern smell í wiki er í grundvallaratriðum a Page ..With í Page við höfum Relavent efni .. ",
	};
	
	two_checkout 	= {
			
		termsAndConditions_en_locale : "I will be showing how to create a Page and add content toit .ok sir Today I want all off you to start puting the feature" 
			+"functionality that has been developed No matter on spelling / Sentence / Grammer .. Just add the data .. Will review as well we can get"
			+"it reviewed by our Pavan if necessary .. If the information is available it will be easy for every on to know as Knowledge base .. and address"
			+"the Enhancements Quickly .. Well now I will add One Page.1. How to add a Page 2. Basic Format to use while adding the content to that Page"
			+"The Structure is like this .. First Main Page as landing Page .. http:wiki.openbillingsystem.com/mw19/ Here you can see 6 Sections .. But we are going to use"
			+"the First one -- Open Billing System Every click in wiki is basically a Page ..With in the Page we have the relavent content ..",
			
		termsAndConditions_is_locale : "Ég mun vera að sýna hvernig á að búa til síðu og bæta við efni Toit .ok herra dag ÉG vilja allir burt þér að byrja puting aðgerðina" 
			+"virkni sem hefur verið þróað Sama á stafsetningu / setning / málfræði .. Bara bæta gögn .. Mun endurskoða eins vel og við getum fengið"
			+"það skoðað af Pavan okkar ef þörf krefur .. Ef upplýsingar liggja það verður auðvelt fyrir alla á að vita sem þekkingargrunn .. og heimilisfang"
			+"að Aukahlutir Fljótt .. Jæja nú er ég mun bæta One Page.1. Hvernig á að bæta við 2. Basic snið til nota en bæta efni á þá síðu"
			+"The Structure er svona .. First Main Page áfangasíðu .. http: wiki.openbillingsystem.com/mw19/ Hér getur þú séð 6 kafla .. En við erum að fara að nota"
			+"Sú fyrsta - Open Billing System Hvern smell í wiki er í grundvallaratriðum a Page ..With í Page við höfum Relavent efni .. ",
	};
	
	selectOnePaymentGatewayText  = {
		
		en	:  "Please select any one Payment Gateway",
		is	:  "Vinsamlegast veldu hvaða einn Greiðsla Hlið",
		
	};
