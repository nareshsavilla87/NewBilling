angular.module('configurations', [])
.constant('TENANT','default')
.constant('API_VERSION','/obsplatform/api/v1')
.constant('CONTENT_TYPE','application/json; charset=utf-8');