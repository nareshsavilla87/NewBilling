(function(selfcare_module) {
   selfcare.models = _.extend(selfcare_module, {
	  url : "https://www.sandbox.paypal.com/cgi-bin/webscr?rm=2&cmd=_xclick&business",	  
	  mail : "lingala.ashokreddy@gmail.com"
  });
}(selfcare.models || {}));
