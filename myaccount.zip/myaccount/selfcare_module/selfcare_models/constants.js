(function(selfcare_module) {
   selfcare.models = _.extend(selfcare_module, {
	   kortaMerchantId 		: "8185318",
	   kortaTerminalId 		: "26460",
	   kortaEncriptionKey 	: "Hugo Technologys",
	   kortaSecretCode 		: "aXVspr9GY4rEwwUGKI75jDerw7iRhkw388h23fVA",
	   kortaTestServer 		: "TEST",
	   kortaAmountField 	: "amount",
	   kortaclientId  		: 'clientId',
	   kortaPaymentMethod	: "PaymentMethodType",
	   kortaTokenValue		: "kortaToken"
		   
  });
}(selfcare.models || {}));
