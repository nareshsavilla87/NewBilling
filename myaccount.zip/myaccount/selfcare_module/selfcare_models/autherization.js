(function(selfcare_module) {
   selfcare.models = _.extend(selfcare_module, {
	   
	   obs_username : "billing",
	   obs_password : "password"
  });
}(selfcare.models || {}));