(function(selfcare_module) {
   selfcare.models = _.extend(selfcare_module, {
	   
	   obs_username : "selfcare",
	   obs_password : "selfcare"
  });
}(selfcare.models || {}));