(function(module) {
  mifosX.models = _.extend(module, {
	  url : "https://www.sandbox.paypal.com/cgi-bin/webscr?rm=2&cmd=_xclick&business",	  
	  mail : "lingala.ashokreddy@gmail.com"
  });
}(mifosX.models || {}));
