(function(module) {
  mifosX.controllers = _.extend(module, {
	  ViewDataTableEntryController: function(scope, location, routeParams, route, resourceFactory,$modal,$rootScope,webStorage) {
    	
    	var clientData = webStorage.get('clientData');
  	    scope.hwSerialNumber=clientData.hwSerialNumber;
        scope.displayName=clientData.displayName;
        scope.statusActive=clientData.statusActive;
        scope.accountNo=clientData.accountNo;
        scope.officeName=clientData.officeName;
        scope.balanceAmount=clientData.balanceAmount;
        scope.currency=clientData.currency;
        scope.imagePresent=clientData.imagePresent;
        scope.categoryType=clientData.categoryType;
        scope.email=clientData.email;
        scope.phone=clientData.phone;
        scope.clientId=routeParams.entityId;

    	   if (routeParams.tableName) {
               scope.tableName = routeParams.tableName;
           }
           if (routeParams.entityId) {
               scope.entityId = routeParams.entityId;
           }
           if (routeParams.resourceId) {
               scope.resourceId = routeParams.resourceId;
           }
           scope.formDat = {};
           scope.columnHeaders = [];
           scope.formData = {};
           scope.isViewMode = true;
           if(routeParams.mode && routeParams.mode == 'edit'){
               scope.isViewMode = false;
           }

           var reqparams = {datatablename: scope.tableName, entityId: scope.entityId, genericResultSet: 'true'};
           if (scope.resourceId) {
               reqparams.resourceId = scope.resourceId;
           }
           
           resourceFactory.DataTablesResource.getTableDetails(reqparams, function (data) {
               for (var i in data.columnHeaders) {
                   if (data.columnHeaders[i].columnCode) {
                       //logic for display codeValue instead of codeId in view datatable details
                       for (var j in data.columnHeaders[i].columnValues) {
                           if(data.columnHeaders[i].columnDisplayType=='CODELOOKUP'){
                               if (data.data[0].row[i] == data.columnHeaders[i].columnValues[j].id) {
                                   data.columnHeaders[i].value = data.columnHeaders[i].columnValues[j].value;
                               }
                           } else if(data.columnHeaders[i].columnDisplayType=='CODEVALUE'){
                               if (data.data[0].row[i] == data.columnHeaders[i].columnValues[j].value) {
                                   data.columnHeaders[i].value = data.columnHeaders[i].columnValues[j].value;
                               }
                           }
                       }
                   } else {
                       data.columnHeaders[i].value = data.data[0].row[i];
                   }
               }
               scope.columnHeaders = data.columnHeaders;
               if(routeParams.mode && routeParams.mode == 'edit'){
                   scope.editDatatableEntry();
               }
           });

           //return input type
           scope.fieldType = function (type) {
               var fieldType = "";
               if (type) {
                   if (type == 'STRING' || type == 'INTEGER' || type == 'TEXT' || type == 'DECIMAL') {
                       fieldType = 'TEXT';
                   } else if (type == 'CODELOOKUP' || type == 'CODEVALUE') {
                       fieldType = 'SELECT';
                   } else if (type == 'DATE') {
                       fieldType = 'DATE';
                   }
               }
               return fieldType;
           };
           

      scope.editDatatableEntry = function () {
        scope.isViewMode = false;
        var colName = scope.columnHeaders[0].columnName;
        if(colName == 'id') { scope.columnHeaders.splice(0,1); }

        colName = scope.columnHeaders[0].columnName;
        if(colName == 'client_id' || colName == 'office_id' || colName == 'group_id' || colName == 'center_id' || colName == 'loan_id' || colName == 'savings_account_id') {
          scope.columnHeaders.splice(0,1);
          scope.isCenter = colName ==  'center_id' ? true : false;
        }

        for (var i in scope.columnHeaders) {

            if (scope.columnHeaders[i].columnDisplayType == 'DATE') {
                scope.formDat[scope.columnHeaders[i].columnName] = scope.columnHeaders[i].value;
            } else {
                scope.formData[scope.columnHeaders[i].columnName] = scope.columnHeaders[i].value;
            }
            if (scope.columnHeaders[i].columnCode) {
                for (var j in scope.columnHeaders[i].columnValues) {
                    if (scope.columnHeaders[i].value == scope.columnHeaders[i].columnValues[j].value) {
                        if(scope.columnHeaders[i].columnDisplayType=='CODELOOKUP'){
                            scope.formData[scope.columnHeaders[i].columnName] = scope.columnHeaders[i].columnValues[j].id;
                        } else if(scope.columnHeaders[i].columnDisplayType=='CODEVALUE'){
                            scope.formData[scope.columnHeaders[i].columnName] = scope.columnHeaders[i].columnValues[j].value;
                        }
                    }
                }
            }
        }
      };
        scope.deleteDatatableEntry = function (){
            $modal.open({
                templateUrl: 'deletedatatable.html',
                controller: DatatableDeleteCtrl
            });
        };
        var DatatableDeleteCtrl = function ($scope, $modalInstance) {
            $scope.delete = function () {
                resourceFactory.DataTablesResource.delete(reqparams, {}, function(data){
                    var destination = "";
                    if ( data.loanId) {
                        destination = '/viewloanaccount/'+data.loanId;
                    } else if ( data.savingsId) {
                        destination = '/viewsavingaccount/' + data.savingsId;
                    } else if ( data.clientId) {
                        destination = '/viewclient/'+data.clientId;
                    } else if ( data.groupId) {
                        if (scope.isCenter) {
                            destination = '/viewcenter/'+data.groupId;
                        } else {
                            destination = '/viewgroup/'+data.groupId;
                        }
                    } else if ( data.officeId) {
                        destination = '/viewoffice/'+data.officeId;
                    }
                    location.path(destination);
                });
                $modalInstance.close('delete');
            };
            $scope.cancel = function () {
                $modalInstance.dismiss('cancel');
            };
        };

        scope.cancel = function () {
            if(routeParams.mode){
                window.history.back();
            } else{
                route.reload();
            }

        };

      scope.submit = function () {
        this.formData.locale = $rootScope.locale.code;
        this.formData.dateFormat =  'dd MMMM yyyy';
        for (var i = 0; i < scope.columnHeaders.length; i++) {
         //below logic, for the input field if data is null from DB, then columnName value send "" to server side
         //if (!_.contains(_.keys(this.formData), scope.columnHeaders[i].columnName))
        	if(this.formData[scope.columnHeaders[i].columnName]==null){
                this.formData[scope.columnHeaders[i].columnName] = "";
            }
            if (scope.columnHeaders[i].columnDisplayType == 'DATE') {
                this.formData[scope.columnHeaders[i].columnName] = dateFilter(this.formDat[scope.columnHeaders[i].columnName], scope.df);
            };
        }
        resourceFactory.DataTablesResource.update(reqparams, this.formData, function(data){
          var destination = "";
          if ( data.loanId) {
            destination = '/viewloanaccount/'+data.loanId;
          } else if ( data.savingsId) {
            destination = '/viewsavingaccount/' + data.savingsId;
          } else if ( data.clientId) {
            destination = '/viewclient/'+data.clientId;
          } else if ( data.groupId) {
              if (scope.isCenter) {
                  destination = '/viewcenter/'+data.groupId;
              } else {
                  destination = '/viewgroup/'+data.groupId;
              }
          } else if ( data.officeId) {
            destination = '/viewoffice/'+data.officeId;
          }
          location.path(destination);
        });
      };

    }
  });
  mifosX.ng.application.controller('ViewDataTableEntryController', ['$scope', '$location', '$routeParams', '$route', 'ResourceFactory','$modal','$rootScope','webStorage', mifosX.controllers.ViewDataTableEntryController]).run(function($log) {
    $log.info("ViewDataTableEntryController initialized");
  });
}(mifosX.controllers || {}));
